import { combineReducers } from 'redux';
import movieReducer from './movieReducer';

const rootReduce = combineReducers({
    movieReducer
})

export default rootReduce;