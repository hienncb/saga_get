export const ADD_MOVIE = "ADD_MOVIE";
export const FETCH_MOVIES = "FETCH_MOVIES";

export const FETCH_SUCCEEDED = "FETCH_SUCCEEDED";
export const FETCH_FAILED = "FETCH_FAILED"; 
